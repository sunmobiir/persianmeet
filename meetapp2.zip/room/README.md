# meetapp
meetapp is free adobe connect alternatives for visual classrooms , online meetings, screen share,   webinars , video and audio conferencing.
<h2 align="center">Features</h2>
<p><p>
  <ul>
<li>Advanced interactive whiteboard </li>
<li>Collaboration online Office suite  </li>
    <li>Team collaboration</li>
<li> Chat </li>
<li>Desktop sharing</li>
    <li>Video and audio conferencing</li>
     <li>File sharing</li>
     <li>Polls</li>
     <li>Play video file</li>
     <li>Collaboration diagram</li>
     <li>Collaboration math editor</li>
    <li>Member roles</li>
</ul>
<h4>online demo </h4>
<a href='https://en.learn100.ir/'>demo</a>
<h4>os support</h4>
<ul>
  <li>Linux server</li>
  <li>Windows server</li>
  <li>FreeBSD </li>
  </ul>
<h4  ><strong>Requirements</strong></h4>
<ul>
  <li>ip</li>
  <li>domain or subdomain</li>
  </ul>
 
 
<p style="text-align: left;">The installation process is very easy and can be installed in less than 5 minutes</p>
  # install meetapp
    